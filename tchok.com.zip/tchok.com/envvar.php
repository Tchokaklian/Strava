<?php
    $dbHost = 'tchokcommcdbo100.mysql.db';
    $dbBase = 'tchokcommcdbo100';
    $dbUser = 'tchokcommcdbo100';
    $dbPassword = 'Sarkis19';
?>

